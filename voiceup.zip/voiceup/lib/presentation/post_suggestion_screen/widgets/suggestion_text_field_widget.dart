import 'dart:ui';
import 'package:flutter/material.dart';
import '../../../theme/app_theme.dart';

// V5 Glassmorphism FormField — LOCKED
// AnimatedContainer label float + focus animation

class SuggestionTextFieldWidget extends StatefulWidget {
  final TextEditingController controller;
  final FocusNode focusNode;
  final int maxChars;
  final int minChars;

  const SuggestionTextFieldWidget({
    super.key,
    required this.controller,
    required this.focusNode,
    required this.maxChars,
    required this.minChars,
  });

  @override
  State<SuggestionTextFieldWidget> createState() =>
      _SuggestionTextFieldWidgetState();
}

class _SuggestionTextFieldWidgetState extends State<SuggestionTextFieldWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _focusAnim;
  late Animation<double> _borderGlow;
  bool _isFocused = false;

  @override
  void initState() {
    super.initState();
    _focusAnim = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 250),
    );
    _borderGlow = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _focusAnim, curve: Curves.easeOutCubic));
    widget.focusNode.addListener(() {
      setState(() => _isFocused = widget.focusNode.hasFocus);
      if (widget.focusNode.hasFocus) {
        _focusAnim.forward();
      } else {
        _focusAnim.reverse();
      }
    });
    widget.controller.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _focusAnim.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final charCount = widget.controller.text.length;
    final isOverLimit = charCount > widget.maxChars;
    final isUnderMin = charCount < widget.minChars && charCount > 0;

    return AnimatedBuilder(
      animation: _borderGlow,
      builder: (context, child) {
        return ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
            child: Container(
              decoration: BoxDecoration(
                color: AppTheme.glassSurface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: isOverLimit
                      ? AppTheme.error
                      : _isFocused
                      ? AppTheme.neonPurple.withOpacity(
                          0.4 + _borderGlow.value * 0.6,
                        )
                      : AppTheme.glassBorder,
                  width: _isFocused ? 1.5 : 1.0,
                ),
                boxShadow: _isFocused
                    ? [
                        BoxShadow(
                          color: AppTheme.neonPurple.withOpacity(
                            0.08 * _borderGlow.value,
                          ),
                          blurRadius: 16,
                          spreadRadius: 2,
                        ),
                      ]
                    : null,
              ),
              child: Column(
                children: [
                  // Hint row
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.edit_rounded,
                          size: 14,
                          color: AppTheme.textMuted,
                        ),
                        const SizedBox(width: 6),
                        const Text(
                          'Be specific and constructive',
                          style: TextStyle(
                            fontFamily: 'Manrope',
                            fontSize: 11,
                            color: AppTheme.textMuted,
                          ),
                        ),
                        const Spacer(),
                        // Character counter
                        Text(
                          '$charCount/${widget.maxChars}',
                          style: TextStyle(
                            fontFamily: 'Manrope',
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            color: isOverLimit
                                ? AppTheme.error
                                : isUnderMin
                                ? AppTheme.warning
                                : AppTheme.textMuted,
                          ),
                        ),
                      ],
                    ),
                  ),
                  TextField(
                    controller: widget.controller,
                    focusNode: widget.focusNode,
                    maxLines: 7,
                    minLines: 5,
                    style: const TextStyle(
                      fontFamily: 'Manrope',
                      fontSize: 14,
                      color: AppTheme.textPrimary,
                      height: 1.6,
                    ),
                    decoration: const InputDecoration(
                      hintText:
                          'e.g. "The library should extend its hours to midnight during exam season. Many students need a quiet study space..."',
                      hintStyle: TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 13,
                        color: AppTheme.textDisabled,
                        height: 1.6,
                      ),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.fromLTRB(16, 8, 16, 16),
                    ),
                  ),
                  // Min chars indicator
                  if (isUnderMin || charCount == 0)
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                      child: Row(
                        children: [
                          Icon(
                            Icons.info_outline_rounded,
                            size: 12,
                            color: AppTheme.warning.withAlpha(204),
                          ),
                          const SizedBox(width: 4),
                          Text(
                            charCount == 0
                                ? 'Minimum ${widget.minChars} characters required'
                                : '${widget.minChars - charCount} more characters needed',
                            style: TextStyle(
                              fontFamily: 'Manrope',
                              fontSize: 11,
                              color: AppTheme.warning.withAlpha(204),
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
