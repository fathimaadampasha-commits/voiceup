import 'dart:ui';
import 'package:flutter/material.dart';
import '../../../theme/app_theme.dart';

class CooldownTimerWidget extends StatelessWidget {
  final int secondsRemaining;

  const CooldownTimerWidget({super.key, required this.secondsRemaining});

  String _formatTime(int seconds) {
    final m = seconds ~/ 60;
    final s = seconds % 60;
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final progress = secondsRemaining / 300.0;

    return ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: AppTheme.warning.withAlpha(15),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppTheme.warning.withAlpha(64), width: 1),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: AppTheme.warning.withAlpha(31),
                  shape: BoxShape.circle,
                ),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    SizedBox(
                      width: 34,
                      height: 34,
                      child: CircularProgressIndicator(
                        value: progress,
                        backgroundColor: AppTheme.warning.withAlpha(38),
                        valueColor: const AlwaysStoppedAnimation<Color>(
                          AppTheme.warning,
                        ),
                        strokeWidth: 2.5,
                      ),
                    ),
                    const Icon(
                      Icons.timer_rounded,
                      color: AppTheme.warning,
                      size: 14,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Anti-Spam Cooldown Active',
                      style: TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.warning,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Next post available in ${_formatTime(secondsRemaining)}',
                      style: const TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 11,
                        color: AppTheme.textMuted,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
