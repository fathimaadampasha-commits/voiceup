import 'dart:ui';
import 'package:flutter/material.dart';
import '../../../theme/app_theme.dart';

// Anatomy locked: animated status row with icon + label + progress indicator
// Pulsing animation during check — LOCKED

enum AiModerationState { idle, checking, approved, flagged, blocked }

class AiModerationStatusWidget extends StatefulWidget {
  final AiModerationState state;
  final String message;
  final double toxicityScore;

  const AiModerationStatusWidget({
    super.key,
    required this.state,
    required this.message,
    required this.toxicityScore,
  });

  @override
  State<AiModerationStatusWidget> createState() =>
      _AiModerationStatusWidgetState();
}

class _AiModerationStatusWidgetState extends State<AiModerationStatusWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;
  late Animation<double> _pulse;
  late Animation<double> _entranceFade;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);

    _pulse = Tween<double>(begin: 0.85, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
    _entranceFade = CurvedAnimation(
      parent: AnimationController(
        vsync: this,
        duration: const Duration(milliseconds: 300),
      )..forward(),
      curve: Curves.easeOut,
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.state == AiModerationState.idle) return const SizedBox.shrink();

    final config = _stateConfig(widget.state);

    return ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: config.bgColor,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: config.borderColor, width: 1),
          ),
          child: Column(
            children: [
              Row(
                children: [
                  // Pulsing icon for checking state
                  if (widget.state == AiModerationState.checking)
                    AnimatedBuilder(
                      animation: _pulse,
                      builder: (_, child) =>
                          Transform.scale(scale: _pulse.value, child: child),
                      child: Container(
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          color: config.iconColor.withAlpha(38),
                          shape: BoxShape.circle,
                        ),
                        child: Center(
                          child: SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: config.iconColor,
                            ),
                          ),
                        ),
                      ),
                    )
                  else
                    Container(
                      width: 32,
                      height: 32,
                      decoration: BoxDecoration(
                        color: config.iconColor.withAlpha(38),
                        shape: BoxShape.circle,
                      ),
                      child: Center(
                        child: Icon(
                          config.icon,
                          color: config.iconColor,
                          size: 16,
                        ),
                      ),
                    ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          config.title,
                          style: TextStyle(
                            fontFamily: 'Manrope',
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: config.iconColor,
                          ),
                        ),
                        if (widget.message.isNotEmpty) ...[
                          const SizedBox(height: 2),
                          Text(
                            widget.message,
                            style: const TextStyle(
                              fontFamily: 'Manrope',
                              fontSize: 11,
                              color: AppTheme.textMuted,
                              height: 1.4,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  // AI badge
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 3,
                    ),
                    decoration: BoxDecoration(
                      color: config.iconColor.withAlpha(26),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      'AI',
                      style: TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        color: config.iconColor,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                ],
              ),
              // Toxicity score bar (only when not checking)
              if (widget.state != AiModerationState.checking &&
                  widget.toxicityScore > 0) ...[
                const SizedBox(height: 10),
                Row(
                  children: [
                    const Text(
                      'Safety Score',
                      style: TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 10,
                        color: AppTheme.textMuted,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      '${((1 - widget.toxicityScore) * 100).toInt()}%',
                      style: TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: config.iconColor,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(999),
                  child: LinearProgressIndicator(
                    value: 1 - widget.toxicityScore,
                    backgroundColor: config.iconColor.withAlpha(31),
                    valueColor: AlwaysStoppedAnimation<Color>(config.iconColor),
                    minHeight: 4,
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  _ModerationConfig _stateConfig(AiModerationState state) {
    switch (state) {
      case AiModerationState.checking:
        return _ModerationConfig(
          title: 'AI is reviewing your suggestion…',
          icon: Icons.auto_fix_high_rounded,
          iconColor: AppTheme.neonPurple,
          bgColor: AppTheme.neonPurple.withAlpha(15),
          borderColor: AppTheme.neonPurple.withAlpha(51),
        );
      case AiModerationState.approved:
        return _ModerationConfig(
          title: 'Safe to Post ✓',
          icon: Icons.check_circle_rounded,
          iconColor: AppTheme.neonGreen,
          bgColor: AppTheme.neonGreen.withAlpha(15),
          borderColor: AppTheme.neonGreen.withAlpha(64),
        );
      case AiModerationState.flagged:
        return _ModerationConfig(
          title: 'Needs Improvement',
          icon: Icons.warning_amber_rounded,
          iconColor: AppTheme.warning,
          bgColor: AppTheme.warning.withAlpha(15),
          borderColor: AppTheme.warning.withAlpha(64),
        );
      case AiModerationState.blocked:
        return _ModerationConfig(
          title: 'Content Blocked',
          icon: Icons.block_rounded,
          iconColor: AppTheme.error,
          bgColor: AppTheme.error.withAlpha(15),
          borderColor: AppTheme.error.withAlpha(64),
        );
      default:
        return _ModerationConfig(
          title: '',
          icon: Icons.circle,
          iconColor: AppTheme.textMuted,
          bgColor: Colors.transparent,
          borderColor: Colors.transparent,
        );
    }
  }
}

class _ModerationConfig {
  final String title;
  final IconData icon;
  final Color iconColor;
  final Color bgColor;
  final Color borderColor;

  const _ModerationConfig({
    required this.title,
    required this.icon,
    required this.iconColor,
    required this.bgColor,
    required this.borderColor,
  });
}
