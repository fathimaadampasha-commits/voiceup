import 'dart:ui';
import 'package:flutter/material.dart';
import '../../../theme/app_theme.dart';

class PostGuidelinesWidget extends StatelessWidget {
  const PostGuidelinesWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.glassSurface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.glassBorder),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Row(
                children: [
                  Icon(
                    Icons.shield_rounded,
                    color: AppTheme.neonPurple,
                    size: 16,
                  ),
                  SizedBox(width: 8),
                  Text(
                    'Community Guidelines',
                    style: TextStyle(
                      fontFamily: 'Manrope',
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.textPrimary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              ..._guidelines.map(
                (g) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 6,
                        height: 6,
                        margin: const EdgeInsets.only(top: 5),
                        decoration: BoxDecoration(
                          color: g['allowed'] as bool
                              ? AppTheme.neonGreen
                              : AppTheme.error,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          g['text'] as String,
                          style: const TextStyle(
                            fontFamily: 'Manrope',
                            fontSize: 12,
                            color: AppTheme.textMuted,
                            height: 1.5,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppTheme.neonGreen.withAlpha(15),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppTheme.neonGreen.withAlpha(51)),
                ),
                child: const Row(
                  children: [
                    Icon(
                      Icons.lock_rounded,
                      color: AppTheme.neonGreen,
                      size: 12,
                    ),
                    SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        'Your identity is never stored or shared. Admins only see anonymous session IDs.',
                        style: TextStyle(
                          fontFamily: 'Manrope',
                          fontSize: 11,
                          color: AppTheme.neonGreen,
                          height: 1.4,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  static const List<Map<String, dynamic>> _guidelines = [
    {
      'text': '✓ Allowed: "Need more practical labs for CS students"',
      'allowed': true,
    },
    {
      'text': '✓ Allowed: "Library timings should extend to midnight"',
      'allowed': true,
    },
    {
      'text': '✗ Blocked: Personal attacks on faculty or staff',
      'allowed': false,
    },
    {
      'text': '✗ Blocked: Abusive, hateful, or threatening language',
      'allowed': false,
    },
    {
      'text': '✗ Blocked: Repeated duplicate or spam submissions',
      'allowed': false,
    },
  ];
}
