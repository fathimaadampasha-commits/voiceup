import 'package:flutter/material.dart';
import '../../../theme/app_theme.dart';

// Anatomy locked: horizontal scroll pill chips
// Image 2 Screen 2.3 — pill row structure adapted for categories

class CategorySelectorWidget extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onSelected;

  const CategorySelectorWidget({
    super.key,
    required this.selectedIndex,
    required this.onSelected,
  });

  static const List<Map<String, dynamic>> _categories = [
    {
      'label': 'Academic',
      'icon': Icons.school_rounded,
      'color': Color(0xFF3B82F6),
    },
    {
      'label': 'Campus',
      'icon': Icons.location_city_rounded,
      'color': Color(0xFFF59E0B),
    },
    {
      'label': 'Tech & WiFi',
      'icon': Icons.wifi_rounded,
      'color': Color(0xFF8B5CF6),
    },
    {
      'label': 'Welfare',
      'icon': Icons.favorite_rounded,
      'color': Color(0xFF10B981),
    },
    {
      'label': 'Safety',
      'icon': Icons.health_and_safety_rounded,
      'color': Color(0xFFEF4444),
    },
    {
      'label': 'Sports',
      'icon': Icons.sports_rounded,
      'color': Color(0xFFEC4899),
    },
    {
      'label': 'Food',
      'icon': Icons.restaurant_rounded,
      'color': Color(0xFFFF8C00),
    },
    {
      'label': 'Transport',
      'icon': Icons.directions_bus_rounded,
      'color': Color(0xFF06B6D4),
    },
  ];

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 44,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: _categories.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final cat = _categories[index];
          final isSelected = index == selectedIndex;
          final color = cat['color'] as Color;

          return GestureDetector(
            onTap: () => onSelected(index),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              curve: Curves.easeOutCubic,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: isSelected ? color.withAlpha(46) : AppTheme.glassSurface,
                borderRadius: BorderRadius.circular(999),
                border: Border.all(
                  color: isSelected
                      ? color.withAlpha(128)
                      : AppTheme.glassBorder,
                  width: 1.2,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    cat['icon'] as IconData,
                    size: 14,
                    color: isSelected ? color : AppTheme.textMuted,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    cat['label'] as String,
                    style: TextStyle(
                      fontFamily: 'Manrope',
                      fontSize: 12,
                      fontWeight: isSelected
                          ? FontWeight.w700
                          : FontWeight.w500,
                      color: isSelected ? color : AppTheme.textMuted,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
