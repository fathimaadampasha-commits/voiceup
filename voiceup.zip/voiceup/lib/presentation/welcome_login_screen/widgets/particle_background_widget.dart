import 'dart:math';
import 'package:flutter/material.dart';
import '../../../theme/app_theme.dart';

// V2 Particle / Dot Field — animated floating dots — LOCKED

class ParticleBackgroundWidget extends StatefulWidget {
  const ParticleBackgroundWidget({super.key});

  @override
  State<ParticleBackgroundWidget> createState() =>
      _ParticleBackgroundWidgetState();
}

class _ParticleBackgroundWidgetState extends State<ParticleBackgroundWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  final List<_Particle> _particles = [];
  final Random _rng = Random();

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();

    for (int i = 0; i < 40; i++) {
      _particles.add(
        _Particle(
          x: _rng.nextDouble(),
          y: _rng.nextDouble(),
          radius: _rng.nextDouble() * 2.5 + 0.5,
          speed: _rng.nextDouble() * 0.004 + 0.001,
          opacity: _rng.nextDouble() * 0.5 + 0.1,
          color: _rng.nextBool() ? AppTheme.neonPurple : AppTheme.neonGreen,
          phase: _rng.nextDouble() * 2 * pi,
        ),
      );
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        return CustomPaint(
          painter: _ParticlePainter(
            particles: _particles,
            progress: _controller.value,
          ),
          size: Size.infinite,
        );
      },
    );
  }
}

class _Particle {
  final double x;
  double y;
  final double radius;
  final double speed;
  final double opacity;
  final Color color;
  final double phase;

  _Particle({
    required this.x,
    required this.y,
    required this.radius,
    required this.speed,
    required this.opacity,
    required this.color,
    required this.phase,
  });
}

class _ParticlePainter extends CustomPainter {
  final List<_Particle> particles;
  final double progress;

  const _ParticlePainter({required this.particles, required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    for (final p in particles) {
      final yOffset = (p.y - progress * p.speed * 10) % 1.0;
      final xWave = p.x + sin(progress * 2 * pi + p.phase) * 0.02;
      final paint = Paint()
        ..color = p.color.withOpacity(p.opacity)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(
        Offset(xWave * size.width, yOffset * size.height),
        p.radius,
        paint,
      );
    }

    // Subtle radial glow at center
    final center = Offset(size.width / 2, size.height * 0.35);
    final glowPaint = Paint()
      ..shader = RadialGradient(
        colors: [AppTheme.neonPurple.withAlpha(31), Colors.transparent],
      ).createShader(Rect.fromCircle(center: center, radius: size.width * 0.6));
    canvas.drawCircle(center, size.width * 0.6, glowPaint);
  }

  @override
  bool shouldRepaint(_ParticlePainter old) => old.progress != progress;
}
