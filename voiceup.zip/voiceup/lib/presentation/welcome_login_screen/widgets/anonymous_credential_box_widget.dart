import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../../theme/app_theme.dart';

// V5 Glassmorphism FormField — LOCKED
// Anatomy locked: generated username display + password field + login CTA pill

class AnonymousCredentialBoxWidget extends StatelessWidget {
  final String username;
  final String avatarSeed;
  final TextEditingController passwordController;
  final bool obscurePassword;
  final VoidCallback onToggleObscure;
  final VoidCallback onRegenerateIdentity;

  const AnonymousCredentialBoxWidget({
    super.key,
    required this.username,
    required this.avatarSeed,
    required this.passwordController,
    required this.obscurePassword,
    required this.onToggleObscure,
    required this.onRegenerateIdentity,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: AppTheme.glassSurface,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: AppTheme.glassBorder, width: 1),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildSectionLabel('Your Anonymous Identity'),
              const SizedBox(height: 12),
              _buildUsernameDisplay(context),
              const SizedBox(height: 16),
              _buildSectionLabel('Set Your Secret Password'),
              const SizedBox(height: 10),
              _buildPasswordField(),
              const SizedBox(height: 8),
              _buildPasswordHint(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionLabel(String label) {
    return Text(
      label,
      style: const TextStyle(
        fontFamily: 'Manrope',
        fontSize: 11,
        fontWeight: FontWeight.w600,
        color: AppTheme.textMuted,
        letterSpacing: 0.8,
      ),
    );
  }

  Widget _buildUsernameDisplay(BuildContext context) {
    final avatarColors = _avatarColors(avatarSeed);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: AppTheme.neonPurple.withAlpha(20),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.neonPurple.withAlpha(64), width: 1),
      ),
      child: Row(
        children: [
          // Generated avatar
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: avatarColors,
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                username.isNotEmpty ? username[0].toUpperCase() : '?',
                style: const TextStyle(
                  fontFamily: 'Manrope',
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  username,
                  style: const TextStyle(
                    fontFamily: 'Manrope',
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.textPrimary,
                  ),
                ),
                const Text(
                  'Auto-generated • Truly anonymous',
                  style: TextStyle(
                    fontFamily: 'Manrope',
                    fontSize: 11,
                    color: AppTheme.textMuted,
                  ),
                ),
              ],
            ),
          ),
          // Copy button
          GestureDetector(
            onTap: () {
              Clipboard.setData(ClipboardData(text: username));
            },
            child: Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: AppTheme.glassSurface,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppTheme.glassBorder),
              ),
              child: const Center(
                child: Icon(
                  Icons.copy_rounded,
                  size: 14,
                  color: AppTheme.textMuted,
                ),
              ),
            ),
          ),
          const SizedBox(width: 6),
          // Regenerate
          GestureDetector(
            onTap: onRegenerateIdentity,
            child: Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: AppTheme.neonPurpleMuted,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppTheme.neonPurple.withAlpha(77)),
              ),
              child: const Center(
                child: Icon(
                  Icons.refresh_rounded,
                  size: 14,
                  color: AppTheme.neonPurple,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPasswordField() {
    return TextFormField(
      controller: passwordController,
      obscureText: obscurePassword,
      style: const TextStyle(
        fontFamily: 'Manrope',
        fontSize: 15,
        color: AppTheme.textPrimary,
      ),
      decoration: InputDecoration(
        hintText: 'Create a secret password',
        hintStyle: const TextStyle(
          fontFamily: 'Manrope',
          fontSize: 14,
          color: AppTheme.textDisabled,
        ),
        filled: true,
        fillColor: AppTheme.glassSurface,
        prefixIcon: const Padding(
          padding: EdgeInsets.only(left: 14, right: 8),
          child: Icon(Icons.lock_rounded, color: AppTheme.textMuted, size: 18),
        ),
        prefixIconConstraints: const BoxConstraints(minWidth: 0, minHeight: 0),
        suffixIcon: GestureDetector(
          onTap: onToggleObscure,
          child: Padding(
            padding: const EdgeInsets.only(right: 14),
            child: Icon(
              obscurePassword
                  ? Icons.visibility_off_rounded
                  : Icons.visibility_rounded,
              color: AppTheme.textMuted,
              size: 18,
            ),
          ),
        ),
        suffixIconConstraints: const BoxConstraints(minWidth: 0, minHeight: 0),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppTheme.glassBorder),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppTheme.glassBorder),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppTheme.neonPurple, width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppTheme.error),
        ),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 14,
        ),
      ),
      validator: (v) {
        if (v == null || v.isEmpty) return 'Password is required';
        if (v.length < 6) return 'Minimum 6 characters';
        return null;
      },
    );
  }

  Widget _buildPasswordHint() {
    return Row(
      children: [
        const Icon(
          Icons.info_outline_rounded,
          size: 12,
          color: AppTheme.textMuted,
        ),
        const SizedBox(width: 5),
        const Expanded(
          child: Text(
            'Your password is encrypted. We never store personal data.',
            style: TextStyle(
              fontFamily: 'Manrope',
              fontSize: 11,
              color: AppTheme.textMuted,
              height: 1.4,
            ),
          ),
        ),
      ],
    );
  }

  List<Color> _avatarColors(String seed) {
    final hash = seed.codeUnits.fold(0, (prev, el) => prev + el);
    final palettes = [
      [AppTheme.neonPurple, const Color(0xFF3B1F8C)],
      [AppTheme.neonGreen, const Color(0xFF064E3B)],
      [AppTheme.neonPink, const Color(0xFF831843)],
      [const Color(0xFF3B82F6), const Color(0xFF1E3A8A)],
      [const Color(0xFFF59E0B), const Color(0xFF78350F)],
    ];
    return palettes[hash % palettes.length];
  }
}
