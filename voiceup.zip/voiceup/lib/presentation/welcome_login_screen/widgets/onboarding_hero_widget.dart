import 'package:flutter/material.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/custom_image_widget.dart';

// Anatomy locked: illustration container rounded 20px + headline + subtitle
// Image 2 Screen 2.1 skeleton — HeroIllustrationContainer

class OnboardingHeroWidget extends StatelessWidget {
  final Animation<double> pulseAnimation;

  const OnboardingHeroWidget({super.key, required this.pulseAnimation});

  @override
  Widget build(BuildContext context) {
    return ScaleTransition(
      scale: pulseAnimation,
      child: Container(
        width: double.infinity,
        height: 220,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: AppTheme.glassBorder, width: 1),
          gradient: const LinearGradient(
            colors: [Color(0x1A8B5CF6), Color(0x0A10B981)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(
          children: [
            // Background decorative elements
            Positioned(
              top: -20,
              right: -20,
              child: Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppTheme.neonPurple.withAlpha(20),
                ),
              ),
            ),
            Positioned(
              bottom: -30,
              left: -10,
              child: Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppTheme.neonGreen.withAlpha(20),
                ),
              ),
            ),
            // Main illustration
            Center(
              child: CustomImageWidget(
                imageUrl:
                    'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=400&q=80',
                width: 180,
                height: 160,
                fit: BoxFit.contain,
                semanticLabel:
                    'Group of diverse college students collaborating and sharing ideas around a table with laptops',
              ),
            ),
            // Shield badge overlay
            Positioned(
              top: 12,
              right: 14,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 5,
                ),
                decoration: BoxDecoration(
                  color: AppTheme.neonGreen.withAlpha(38),
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(
                    color: AppTheme.neonGreen.withAlpha(102),
                    width: 1,
                  ),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.shield_rounded,
                      color: AppTheme.neonGreen,
                      size: 12,
                    ),
                    SizedBox(width: 4),
                    Text(
                      '100% Anonymous',
                      style: TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.neonGreen,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // AI badge overlay
            Positioned(
              bottom: 12,
              left: 14,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 5,
                ),
                decoration: BoxDecoration(
                  color: AppTheme.neonPurple.withAlpha(38),
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(
                    color: AppTheme.neonPurple.withAlpha(102),
                    width: 1,
                  ),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.auto_fix_high_rounded,
                      color: AppTheme.neonPurple,
                      size: 12,
                    ),
                    SizedBox(width: 4),
                    Text(
                      'AI Moderated',
                      style: TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.neonPurple,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
