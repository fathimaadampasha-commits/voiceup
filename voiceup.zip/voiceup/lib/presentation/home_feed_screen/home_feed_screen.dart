
import '../../core/app_export.dart';
import './widgets/filter_chip_row_widget.dart';
import './widgets/greeting_row_widget.dart';
import './widgets/hero_suggestion_card_widget.dart';
import './widgets/stat_row_widget.dart';
import './widgets/suggestion_feed_card_widget.dart';
import './widgets/trending_section_header_widget.dart';

// TODO: Replace with Riverpod/Bloc for production state management

class HomeFeedScreen extends StatefulWidget {
  const HomeFeedScreen({super.key});

  @override
  State<HomeFeedScreen> createState() => _HomeFeedScreenState();
}

class _HomeFeedScreenState extends State<HomeFeedScreen>
    with TickerProviderStateMixin {
  int _navIndex = 0;
  int _selectedCategoryIndex = 0;
  bool _isLoading = true;
  late AnimationController _listEntranceController;

  // Mock anonymous user data
  // TODO: Replace with Supabase anonymous session data
  final Map<String, dynamic> _currentUser = {
    'username': 'ShadowFox_429',
    'avatarSeed': 'ShadowFox429',
    'totalSuggestions': 7,
    'totalUpvotes': 142,
    'streakDays': 8,
  };

  // Mock hero suggestion (user's own most recent)
  // TODO: Replace with Supabase query for user's latest suggestion
  final Map<String, dynamic> _heroSuggestion = {
    'id': 'sug_001',
    'title': 'Extend library hours to midnight during exam season',
    'category': 'Academic',
    'status': 'underReview',
    'upvotes': 87,
    'lessonProgress': 0.4,
    'daysAgo': 2,
  };

  // Mock feed data
  // TODO: Replace with Supabase realtime subscription
  static final List<Map<String, dynamic>> _feedMaps = [
    {
      'id': 'sug_002',
      'title': 'Campus WiFi is unreliable in Block C labs',
      'body':
          'During peak hours the connection drops completely. Affects online exams and submissions.',
      'category': 'Tech',
      'status': 'approved',
      'upvotes': 234,
      'downvotes': 12,
      'userVote': 'up',
      'timestamp': '3h ago',
      'isHot': true,
      'aiScore': 0.92,
    },
    {
      'id': 'sug_003',
      'title': 'Need more vegetarian options in the main cafeteria',
      'body':
          'Currently only 2 vegetarian dishes are available daily. Students with dietary restrictions have very limited choices.',
      'category': 'Welfare',
      'status': 'pendingReview',
      'upvotes': 156,
      'downvotes': 8,
      'userVote': null,
      'timestamp': '5h ago',
      'isHot': true,
      'aiScore': 0.88,
    },
    {
      'id': 'sug_004',
      'title': 'Add more practical lab sessions for CS students',
      'body':
          'Theoretical lectures alone are insufficient. Industry mentors recommend 60/40 practical-theory split.',
      'category': 'Academic',
      'status': 'underReview',
      'upvotes': 198,
      'downvotes': 5,
      'userVote': 'up',
      'timestamp': '8h ago',
      'isHot': false,
      'aiScore': 0.95,
    },
    {
      'id': 'sug_005',
      'title': 'Install water coolers on every floor of the hostel',
      'body':
          'Students have to walk to the ground floor for drinking water. This is especially difficult during late-night study sessions.',
      'category': 'Campus',
      'status': 'implemented',
      'upvotes': 312,
      'downvotes': 3,
      'userVote': null,
      'timestamp': '1d ago',
      'isHot': false,
      'aiScore': 0.91,
    },
    {
      'id': 'sug_006',
      'title': 'Dedicated mental health counseling slots every week',
      'body':
          'Current appointment wait time is 2–3 weeks. Students in distress need faster access to counseling support.',
      'category': 'Safety',
      'status': 'approved',
      'upvotes': 445,
      'downvotes': 2,
      'userVote': null,
      'timestamp': '2d ago',
      'isHot': true,
      'aiScore': 0.97,
    },
    {
      'id': 'sug_007',
      'title': 'Provide free printing quota for final-year projects',
      'body':
          'Final year students spend thousands on printing project reports. A 100-page free quota per semester would help significantly.',
      'category': 'Academic',
      'status': 'pendingReview',
      'upvotes': 89,
      'downvotes': 14,
      'userVote': null,
      'timestamp': '3d ago',
      'isHot': false,
      'aiScore': 0.84,
    },
    {
      'id': 'sug_008',
      'title':
          'Better lighting on the pathway between Block A and the sports complex',
      'body':
          'The pathway is completely dark after 7pm. Students feel unsafe walking there at night.',
      'category': 'Safety',
      'status': 'underReview',
      'upvotes': 267,
      'downvotes': 4,
      'userVote': 'up',
      'timestamp': '4d ago',
      'isHot': false,
      'aiScore': 0.93,
    },
    {
      'id': 'sug_009',
      'title': 'Student shuttle service to the nearest metro station',
      'body':
          'Many students commute and the auto-rickshaw prices are exploitative. An official shuttle would reduce daily transport costs by 60%.',
      'category': 'Campus',
      'status': 'approved',
      'upvotes': 521,
      'downvotes': 18,
      'userVote': null,
      'timestamp': '5d ago',
      'isHot': true,
      'aiScore': 0.89,
    },
  ];

  late List<Map<String, dynamic>> _feedItems;
  late List<Map<String, dynamic>> _filteredItems;

  final List<String> _categories = [
    'All',
    'Academic',
    'Campus',
    'Tech',
    'Welfare',
    'Safety',
  ];

  @override
  void initState() {
    super.initState();
    _feedItems = _feedMaps;
    _filteredItems = _feedItems;

    _listEntranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );

    // Simulate loading
    // TODO: Replace with actual Supabase data fetch
    Future.delayed(const Duration(milliseconds: 800), () {
      if (mounted) {
        setState(() => _isLoading = false);
        _listEntranceController.forward();
      }
    });
  }

  void _onCategorySelected(int index) {
    setState(() {
      _selectedCategoryIndex = index;
      if (index == 0) {
        _filteredItems = _feedItems;
      } else {
        _filteredItems = _feedItems
            .where((s) => s['category'] == _categories[index])
            .toList();
      }
    });
  }

  void _onVote(String id, String voteType) {
    // TODO: Replace with Supabase vote mutation + anti-spam check
    setState(() {
      final idx = _filteredItems.indexWhere((s) => s['id'] == id);
      if (idx == -1) return;
      final item = Map<String, dynamic>.from(_filteredItems[idx]);
      if (item['userVote'] == voteType) {
        // Undo vote
        item['userVote'] = null;
        if (voteType == 'up') {
          item['upvotes'] = (item['upvotes'] as int) - 1;
        } else {
          item['downvotes'] = (item['downvotes'] as int) - 1;
        }
      } else {
        // Undo previous
        if (item['userVote'] == 'up') {
          item['upvotes'] = (item['upvotes'] as int) - 1;
        } else if (item['userVote'] == 'down') {
          item['downvotes'] = (item['downvotes'] as int) - 1;
        }
        item['userVote'] = voteType;
        if (voteType == 'up') {
          item['upvotes'] = (item['upvotes'] as int) + 1;
        } else {
          item['downvotes'] = (item['downvotes'] as int) + 1;
        }
      }
      _filteredItems[idx] = item;
    });
  }

  void _onNavChanged(int index) {
    if (index == 1) {
      Navigator.pushNamed(context, AppRoutes.postSuggestion);
      return;
    }
    setState(() => _navIndex = index);
  }

  @override
  void dispose() {
    _listEntranceController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isTablet = MediaQuery.of(context).size.width >= 600;

    return Scaffold(
      backgroundColor: AppTheme.backgroundDark,
      extendBody: true,
      body: SafeArea(
        bottom: false,
        child: RefreshIndicator(
          onRefresh: () async {
            // TODO: Replace with Supabase realtime refresh
            await Future.delayed(const Duration(milliseconds: 800));
          },
          color: AppTheme.neonPurple,
          backgroundColor: AppTheme.surfaceDark,
          child: CustomScrollView(
            physics: const BouncingScrollPhysics(),
            slivers: [
              // Glassmorphism AppBar — V3 LOCKED
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                  child: GreetingRowWidget(userData: _currentUser),
                ),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 16)),
              // Hero suggestion card
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: HeroSuggestionCardWidget(suggestion: _heroSuggestion),
                ),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 16)),
              // Stats row
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: StatRowWidget(
                    totalSuggestions: _currentUser['totalSuggestions'] as int,
                    totalUpvotes: _currentUser['totalUpvotes'] as int,
                    streakDays: _currentUser['streakDays'] as int,
                  ),
                ),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 20)),
              // Section header
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: TrendingSectionHeaderWidget(
                    title: 'Community Feed',
                    onSeeAll: () {},
                  ),
                ),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 10)),
              // Filter chips
              SliverToBoxAdapter(
                child: FilterChipRowWidget(
                  categories: _categories,
                  selectedIndex: _selectedCategoryIndex,
                  onSelected: _onCategorySelected,
                ),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 12)),
              // Feed list
              if (_isLoading)
                SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (_, __) => const SuggestionCardSkeleton(),
                    childCount: 5,
                  ),
                )
              else if (_filteredItems.isEmpty)
                SliverFillRemaining(
                  child: EmptyStateWidget(
                    iconName: 'forum',
                    title: 'No suggestions in this category',
                    subtitle:
                        'Be the first to raise a concern in this area. Your voice matters.',
                    ctaLabel: 'Post a Suggestion',
                    onCta: () =>
                        Navigator.pushNamed(context, AppRoutes.postSuggestion),
                  ),
                )
              else
                SliverList(
                  delegate: SliverChildBuilderDelegate((context, index) {
                    final delay = Duration(milliseconds: index * 60);
                    return _AnimatedFeedItem(
                      key: ValueKey(_filteredItems[index]['id']),
                      delay: delay,
                      child:
                          isTablet &&
                              index % 2 == 0 &&
                              index + 1 < _filteredItems.length
                          ? _buildTabletRow(index)
                          : (isTablet && index % 2 != 0
                                ? const SizedBox.shrink()
                                : _buildFeedCard(index)),
                    );
                  }, childCount: _filteredItems.length),
                ),
              // Bottom padding for nav bar
              const SliverToBoxAdapter(child: SizedBox(height: 100)),
            ],
          ),
        ),
      ),
      bottomNavigationBar: AppNavigation(
        selectedIndex: _navIndex,
        onDestinationSelected: _onNavChanged,
      ),
    );
  }

  Widget _buildFeedCard(int index) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: SuggestionFeedCardWidget(
        suggestion: _filteredItems[index],
        onUpvote: () => _onVote(_filteredItems[index]['id'] as String, 'up'),
        onDownvote: () =>
            _onVote(_filteredItems[index]['id'] as String, 'down'),
        onReport: () {
          // TODO: Send report to Supabase moderation queue
        },
      ),
    );
  }

  Widget _buildTabletRow(int index) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: SuggestionFeedCardWidget(
              suggestion: _filteredItems[index],
              onUpvote: () =>
                  _onVote(_filteredItems[index]['id'] as String, 'up'),
              onDownvote: () =>
                  _onVote(_filteredItems[index]['id'] as String, 'down'),
              onReport: () {},
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: SuggestionFeedCardWidget(
              suggestion: _filteredItems[index + 1],
              onUpvote: () =>
                  _onVote(_filteredItems[index + 1]['id'] as String, 'up'),
              onDownvote: () =>
                  _onVote(_filteredItems[index + 1]['id'] as String, 'down'),
              onReport: () {},
            ),
          ),
        ],
      ),
    );
  }
}

class _AnimatedFeedItem extends StatefulWidget {
  final Widget child;
  final Duration delay;

  const _AnimatedFeedItem({
    super.key,
    required this.child,
    required this.delay,
  });

  @override
  State<_AnimatedFeedItem> createState() => _AnimatedFeedItemState();
}

class _AnimatedFeedItemState extends State<_AnimatedFeedItem>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(
      begin: const Offset(0, 0.06),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));

    Future.delayed(widget.delay, () {
      if (mounted) _ctrl.forward();
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(position: _slide, child: widget.child),
    );
  }
}
