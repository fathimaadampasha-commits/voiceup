import 'dart:ui';

import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import './custom_icon_widget.dart';

// TODO: Replace selectedIndex state with Riverpod/Bloc for production

class AppNavigation extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onDestinationSelected;

  const AppNavigation({
    super.key,
    required this.selectedIndex,
    required this.onDestinationSelected,
  });

  @override
  Widget build(BuildContext context) {
    // V3 Liquid Glass — BackdropFilter blur + animated pill + extendBody: true — LOCKED
    return ClipRRect(
      borderRadius: const BorderRadius.only(
        topLeft: Radius.circular(24),
        topRight: Radius.circular(24),
      ),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
        child: Container(
          decoration: const BoxDecoration(
            color: Color(0x1AFFFFFF),
            border: Border(
              top: BorderSide(color: AppTheme.glassBorder, width: 1),
            ),
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(24),
              topRight: Radius.circular(24),
            ),
          ),
          child: SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _NavItem(
                    iconName: 'home',
                    outlinedIconName: 'home_outlined',
                    label: 'Home',
                    index: 0,
                    selectedIndex: selectedIndex,
                    onTap: onDestinationSelected,
                  ),
                  _NavItem(
                    iconName: 'add_circle',
                    outlinedIconName: 'add_circle',
                    label: 'Post',
                    index: 1,
                    selectedIndex: selectedIndex,
                    onTap: onDestinationSelected,
                    isPrimary: true,
                  ),
                  _NavItem(
                    iconName: 'notifications',
                    outlinedIconName: 'notifications_outlined',
                    label: 'Alerts',
                    index: 2,
                    selectedIndex: selectedIndex,
                    onTap: onDestinationSelected,
                  ),
                  _NavItem(
                    iconName: 'person',
                    outlinedIconName: 'person_outlined',
                    label: 'Profile',
                    index: 3,
                    selectedIndex: selectedIndex,
                    onTap: onDestinationSelected,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final String iconName;
  final String outlinedIconName;
  final String label;
  final int index;
  final int selectedIndex;
  final ValueChanged<int> onTap;
  final bool isPrimary;

  const _NavItem({
    required this.iconName,
    required this.outlinedIconName,
    required this.label,
    required this.index,
    required this.selectedIndex,
    required this.onTap,
    this.isPrimary = false,
  });

  @override
  Widget build(BuildContext context) {
    final isSelected = index == selectedIndex;
    return GestureDetector(
      onTap: () => onTap(index),
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOutCubic,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected
              ? (isPrimary ? AppTheme.neonPurple : AppTheme.neonPurpleMuted)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(999),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CustomIconWidget(
              iconName: isSelected ? iconName : outlinedIconName,
              color: isSelected
                  ? (isPrimary ? Colors.white : AppTheme.neonPurple)
                  : AppTheme.textMuted,
              size: isPrimary ? 26 : 22,
            ),
            const SizedBox(height: 3),
            AnimatedDefaultTextStyle(
              duration: const Duration(milliseconds: 200),
              style: TextStyle(
                fontFamily: 'Manrope',
                fontSize: 10,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                color: isSelected
                    ? (isPrimary ? Colors.white : AppTheme.neonPurple)
                    : AppTheme.textMuted,
              ),
              child: Text(label),
            ),
          ],
        ),
      ),
    );
  }
}
