import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

enum SuggestionStatus {
  pendingReview,
  approved,
  underReview,
  implemented,
  rejected,
}

class StatusBadgeWidget extends StatelessWidget {
  final SuggestionStatus status;
  final bool compact;

  const StatusBadgeWidget({
    super.key,
    required this.status,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    final config = _statusConfig(status);
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: compact ? 8 : 10,
        vertical: compact ? 3 : 5,
      ),
      decoration: BoxDecoration(
        color: config.bgColor,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: config.borderColor, width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 5,
            height: 5,
            decoration: BoxDecoration(
              color: config.dotColor,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 5),
          Text(
            config.label,
            style: TextStyle(
              fontFamily: 'Manrope',
              fontSize: compact ? 10 : 11,
              fontWeight: FontWeight.w600,
              color: config.textColor,
              letterSpacing: 0.2,
            ),
          ),
        ],
      ),
    );
  }

  _StatusConfig _statusConfig(SuggestionStatus s) {
    switch (s) {
      case SuggestionStatus.pendingReview:
        return _StatusConfig(
          label: 'Pending Review',
          bgColor: const Color(0x20F59E0B),
          borderColor: const Color(0x40F59E0B),
          dotColor: AppTheme.warning,
          textColor: AppTheme.warning,
        );
      case SuggestionStatus.approved:
        return _StatusConfig(
          label: 'Approved',
          bgColor: const Color(0x2010B981),
          borderColor: const Color(0x4010B981),
          dotColor: AppTheme.neonGreen,
          textColor: AppTheme.neonGreen,
        );
      case SuggestionStatus.underReview:
        return _StatusConfig(
          label: 'Under Review',
          bgColor: const Color(0x203B82F6),
          borderColor: const Color(0x403B82F6),
          dotColor: AppTheme.info,
          textColor: AppTheme.info,
        );
      case SuggestionStatus.implemented:
        return _StatusConfig(
          label: 'Implemented',
          bgColor: const Color(0x208B5CF6),
          borderColor: const Color(0x408B5CF6),
          dotColor: AppTheme.neonPurple,
          textColor: AppTheme.neonPurple,
        );
      case SuggestionStatus.rejected:
        return _StatusConfig(
          label: 'Rejected',
          bgColor: const Color(0x20EF4444),
          borderColor: const Color(0x40EF4444),
          dotColor: AppTheme.error,
          textColor: AppTheme.error,
        );
    }
  }
}

class _StatusConfig {
  final String label;
  final Color bgColor;
  final Color borderColor;
  final Color dotColor;
  final Color textColor;

  const _StatusConfig({
    required this.label,
    required this.bgColor,
    required this.borderColor,
    required this.dotColor,
    required this.textColor,
  });
}
