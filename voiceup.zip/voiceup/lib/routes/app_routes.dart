import 'package:flutter/material.dart';

import '../presentation/home_feed_screen/home_feed_screen.dart';
import '../presentation/post_suggestion_screen/post_suggestion_screen.dart';
import '../presentation/welcome_login_screen/welcome_login_screen.dart';

class AppRoutes {
  static const String initial = '/';
  static const String welcomeLogin = '/welcome-login-screen';
  static const String homeFeed = '/home-feed-screen';
  static const String postSuggestion = '/post-suggestion-screen';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const WelcomeLoginScreen(),
    welcomeLogin: (context) => const WelcomeLoginScreen(),
    homeFeed: (context) => const HomeFeedScreen(),
    postSuggestion: (context) => const PostSuggestionScreen(),
  };
}
